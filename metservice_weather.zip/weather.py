"""Support for MetService weather service.

For more details about this platform, please refer to the documentation at
https://github.com/ciejer/metservice-weather.
"""

from . import WeatherUpdateCoordinator
from homeassistant.config_entries import ConfigEntry
from .const import (
    DOMAIN,
    FIELD_CONDITIONS,
    FIELD_HUMIDITY,
    FIELD_PRESSURE,
    FIELD_TEMP,
    FIELD_WINDDIR,
    FIELD_WINDSPEED,
    LENGTHUNIT,
    MANUFACTURER,
    PRESSUREUNIT,
    SPEEDUNIT,
    TEMPUNIT,
    CONDITION_MAP,
)

import logging
from datetime import datetime

from homeassistant.components.weather import (
    ATTR_FORECAST_PRECIPITATION,
    ATTR_FORECAST_TEMP,
    ATTR_FORECAST_TEMP_LOW,
    ATTR_FORECAST_TIME,
    ATTR_FORECAST_WIND_SPEED,
    ATTR_FORECAST_WIND_BEARING,
    ATTR_FORECAST_CONDITION,
    SingleCoordinatorWeatherEntity,
    WeatherEntityFeature,
    Forecast,
    DOMAIN as WEATHER_DOMAIN,
)

from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers import sun as sun_helper

_LOGGER = logging.getLogger(__name__)

def safe_float(value):
    """Safely convert a value to float, return None if conversion fails."""
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    """Add weather entity."""
    coordinator: WeatherUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]
    if(entry.data["api"] == "mobile"):
        async_add_entities(
            [
                MetServiceForecastMobile(coordinator),
            ]
        )
    else:
        async_add_entities(
            [
                MetServiceForecastPublic(coordinator),
            ]
        )


class MetServiceMobile(SingleCoordinatorWeatherEntity):
    """Implementation of a MetService weather service."""

    def __init__(self, coordinator: WeatherUpdateCoordinator) -> None:
        """Set up MetService device info."""
        super().__init__(coordinator)
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.location)},
            name=coordinator.location_name,
            manufacturer=MANUFACTURER,
        )

    @property
    def native_temperature(self) -> float:
        """Return the platform temperature in native units (i.e. not converted)."""
        return self.coordinator.get_current_mobile(FIELD_TEMP)

    @property
    def native_temperature_unit(self) -> str:
        """Return the native unit of measurement for temperature."""
        return self.coordinator.units_of_measurement[TEMPUNIT]

    @property
    def native_pressure(self) -> float:
        """Return the pressure in native units."""
        return self.coordinator.get_current_mobile(FIELD_PRESSURE)

    @property
    def native_pressure_unit(self) -> str:
        """Return the native unit of measurement for pressure."""
        return self.coordinator.units_of_measurement[PRESSUREUNIT]

    @property
    def humidity(self) -> float:
        """Return the relative humidity in native units."""
        return self.coordinator.get_current_mobile(FIELD_HUMIDITY)

    @property
    def native_wind_speed(self) -> float:
        """Return the wind speed in native units."""
        return self.coordinator.get_current_mobile(FIELD_WINDSPEED)

    @property
    def native_wind_speed_unit(self) -> str:
        """Return the native unit of measurement for wind speed."""
        return self.coordinator.units_of_measurement[SPEEDUNIT]

    @property
    def wind_bearing(self) -> str:
        """Return the wind bearing."""
        return self.coordinator.get_current_mobile(FIELD_WINDDIR)

    @property
    def native_precipitation_unit(self) -> str:
        """Return the native unit of measurement for accumulated precipitation."""
        return self.coordinator.units_of_measurement[LENGTHUNIT]

    @property
    def condition(self) -> str:
        """Return the current condition."""
        raw = self.coordinator.get_current_mobile(FIELD_CONDITIONS)
        mapped = CONDITION_MAP.get(raw, raw)
        if mapped == "sunny" and not sun_helper.is_up(self.hass):
            return "clear-night"
        return mapped


class MetServiceForecastMobile(MetServiceMobile):
    """Implementation of a MetService weather forecast."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: WeatherUpdateCoordinator):
        """Initialize the forecast sensor."""
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.location_name},{WEATHER_DOMAIN}".lower()

    @property
    def supported_features(self) -> WeatherEntityFeature:
        """Return the forecast supported features."""
        return (
            WeatherEntityFeature.FORECAST_HOURLY | WeatherEntityFeature.FORECAST_DAILY
        )

    @property
    def name(self):
        """Return the name of the forecast sensor."""
        return f"{self.coordinator.location_name} Forecast"

    @property
    def extra_state_attributes(self) -> dict[str, object]:
        """Return the state attributes."""
        return {
            'forecast_hourly': self.forecast_hourly,
            'forecast_daily': self.forecast_daily
        }

    async def async_forecast_hourly(self) -> list[Forecast] | None:
        """Return hourly forecast."""
        return self.forecast_hourly

    async def async_forecast_daily(self) -> list[Forecast] | None:
        """Return daily forecast."""
        return self.forecast_daily

    @property
    def forecast_hourly(self) -> list[Forecast]:
        """Return the hourly forecast in native units."""

        forecast = []
        hourly_readings = self.coordinator.get_current_mobile("hourly_base")
        if not hourly_readings:
            return forecast
        for hour in range(len(hourly_readings)):
            this_hour = hourly_readings[hour]

            rain_fall = safe_float(this_hour.get("rainFall"))
            wind_speed = safe_float(this_hour.get("windSpeed"))
            wind_dir = this_hour.get("windDir")
            is_daytime = 7 < datetime.fromisoformat(this_hour["dateISO"]).hour < 19

            if rain_fall is not None and rain_fall > 0:
                if rain_fall > 6:
                    icon = "pouring"
                else:
                    icon = "rainy"
            elif wind_speed is not None and wind_speed > 40:
                icon = "windy"
            elif is_daytime:
                icon = "partlycloudy"
            else:
                icon = "clear-night"

            forecast.append(
                Forecast(
                    {
                        ATTR_FORECAST_TEMP: safe_float(this_hour.get("temperature")),
                        ATTR_FORECAST_TIME: self.coordinator._format_timestamp(
                            this_hour["dateISO"]
                        ),
                        ATTR_FORECAST_PRECIPITATION: rain_fall,
                        ATTR_FORECAST_WIND_SPEED: wind_speed,
                        ATTR_FORECAST_WIND_BEARING: wind_dir,
                        ATTR_FORECAST_CONDITION: icon,
                    }
                )
            )
        return forecast

    @property
    def forecast_daily(self) -> list[Forecast]:
        """Return the daily forecast in native units."""

        forecast = []
        num_days = self.coordinator.get_forecast_daily_mobile("", 0)

        for day in range(0, num_days):
            day_condition = self.coordinator.get_forecast_daily_mobile("daily_condition", day)
            if day_condition in CONDITION_MAP:
                day_condition = CONDITION_MAP[day_condition]
            day_description = self.coordinator.get_forecast_daily_mobile("daily_description", day)
            entry: dict = {
                ATTR_FORECAST_TEMP: self.coordinator.get_forecast_daily_mobile(
                    "daily_temp_high", day
                ),
                ATTR_FORECAST_TEMP_LOW: self.coordinator.get_forecast_daily_mobile(
                    "daily_temp_low", day
                ),
                ATTR_FORECAST_CONDITION: day_condition,
                ATTR_FORECAST_TIME: self.coordinator.get_forecast_daily_mobile("daily_datetime", day),
            }
            if day_description:
                entry["description"] = day_description
            forecast.append(Forecast(entry))
        return forecast

class MetServicePublic(SingleCoordinatorWeatherEntity):
    """Implementation of a MetService weather service."""

    def __init__(self, coordinator: WeatherUpdateCoordinator) -> None:
        """Set up MetService device info."""
        super().__init__(coordinator)
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, coordinator.location)},
            name=coordinator.location_name,
            manufacturer=MANUFACTURER,
        )

    @property
    def native_temperature(self) -> float:
        """Return the platform temperature in native units (i.e. not converted)."""
        return self.coordinator.get_current_public(FIELD_TEMP)

    @property
    def native_temperature_unit(self) -> str:
        """Return the native unit of measurement for temperature."""
        return self.coordinator.units_of_measurement[TEMPUNIT]

    @property
    def native_pressure(self) -> float:
        """Return the pressure in native units."""
        return self.coordinator.get_current_public(FIELD_PRESSURE)

    @property
    def native_pressure_unit(self) -> str:
        """Return the native unit of measurement for pressure."""
        return self.coordinator.units_of_measurement[PRESSUREUNIT]

    @property
    def humidity(self) -> float:
        """Return the relative humidity in native units."""
        humidity = self.coordinator.get_current_public(FIELD_HUMIDITY)
        return int(humidity) if humidity is not None else None

    @property
    def native_wind_speed(self) -> float:
        """Return the wind speed in native units."""
        return self.coordinator.get_current_public(FIELD_WINDSPEED)

    @property
    def native_wind_speed_unit(self) -> str:
        """Return the native unit of measurement for wind speed."""
        return self.coordinator.units_of_measurement[SPEEDUNIT]

    @property
    def wind_bearing(self) -> str:
        """Return the wind bearing."""
        return self.coordinator.get_current_public(FIELD_WINDDIR)

    @property
    def native_precipitation_unit(self) -> str:
        """Return the native unit of measurement for accumulated precipitation."""
        return self.coordinator.units_of_measurement[LENGTHUNIT]

    @property
    def condition(self) -> str:
        """Return the current condition."""
        raw = self.coordinator.get_current_public(FIELD_CONDITIONS)
        mapped = CONDITION_MAP.get(raw, raw)
        if mapped == "sunny" and not sun_helper.is_up(self.hass):
            return "clear-night"
        return mapped


class MetServiceForecastPublic(MetServicePublic):
    """Implementation of a MetService weather forecast."""

    _attr_has_entity_name = True

    def __init__(self, coordinator: WeatherUpdateCoordinator):
        """Initialize the forecast sensor."""
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.location_name},{WEATHER_DOMAIN}".lower()

    @property
    def supported_features(self) -> WeatherEntityFeature:
        """Return the forecast supported features."""
        return (
            WeatherEntityFeature.FORECAST_HOURLY | WeatherEntityFeature.FORECAST_DAILY
        )

    @property
    def name(self):
        """Return the name of the forecast sensor."""
        return f"{self.coordinator.location_name} Forecast"

    @property
    def extra_state_attributes(self) -> dict[str, object]:
        """Return the state attributes."""
        return {
            'forecast_hourly': self.forecast_hourly,
            'forecast_daily': self.forecast_daily
        }


    async def async_forecast_hourly(self) -> list[Forecast] | None:
        """Return hourly forecast."""
        return self.forecast_hourly

    async def async_forecast_daily(self) -> list[Forecast] | None:
        """Return daily forecast."""
        return self.forecast_daily

    @property
    def forecast_hourly(self) -> list[Forecast]:
        """Return the hourly forecast in native units."""

        forecast = []
        hourly_readings = self.coordinator.get_current_public("hourly_temp")
        hourly_obs = self.coordinator.get_current_public("hourly_obs")
        hourly_skip = self.coordinator.get_current_public("hourly_skip")
        if hourly_obs is None:  # Handles regions which do not have daily data
            hourly_obs = self.coordinator.get_current_public("hourly_bkp_obs")

        if hourly_skip is None:
            hourly_skip = self.coordinator.get_current_public("hourly_bkp_skip")

        if hourly_readings is None:
            hourly_readings = self.coordinator.get_current_public("hourly_bkp_temp")

        if not hourly_readings or hourly_obs is None or hourly_skip is None:
            return forecast

        for hour in range(hourly_skip, hourly_obs + hourly_skip):
            this_hour = hourly_readings[hour]

            rainfall = safe_float(this_hour.get("rainfall"))
            wind_speed = safe_float(this_hour["wind"].get("speed"))
            wind_dir = this_hour["wind"].get("direction")
            is_daytime = 7 < datetime.fromisoformat(this_hour["date"]).hour < 19

            if rainfall is not None and rainfall > 0:
                if rainfall > 6:
                    icon = "pouring"
                else:
                    icon = "rainy"
            elif wind_speed is not None and wind_speed > 40:
                icon = "windy"
            elif is_daytime:
                icon = "partlycloudy"
            else:
                icon = "clear-night"

            forecast.append(
                Forecast(
                    {
                        ATTR_FORECAST_TEMP: safe_float(this_hour.get("temperature")),
                        ATTR_FORECAST_TIME: self.coordinator._format_timestamp(
                            this_hour["date"]
                        ),
                        ATTR_FORECAST_PRECIPITATION: rainfall,
                        ATTR_FORECAST_WIND_SPEED: wind_speed,
                        ATTR_FORECAST_WIND_BEARING: wind_dir,
                        ATTR_FORECAST_CONDITION: icon,
                    }
                )
            )
        return forecast

    @property
    def forecast_daily(self) -> list[Forecast]:
        """Return the daily forecast in native units."""

        forecast = []
        num_days = self.coordinator.get_forecast_daily_public("", 0)
        for day in range(0, num_days):
            day_condition = self.coordinator.get_forecast_daily_public("daily_condition", day)
            daily_temp_high = self.coordinator.get_forecast_daily_public("daily_temp_high", day)
            daily_temp_low = self.coordinator.get_forecast_daily_public("daily_temp_low", day)
            daily_datetime = self.coordinator.get_forecast_daily_public("daily_datetime", day)
            day_description = self.coordinator.get_forecast_daily_public("daily_description", day)
            daily_precip_low = self.coordinator.get_forecast_daily_public("daily_rainfall_low", day)
            daily_precip_high = self.coordinator.get_forecast_daily_public("daily_rainfall_high", day)
            if daily_temp_high is None:  # Rural areas have data in a different location
                daily_temp_high = self.coordinator.get_forecast_daily_public("daily_bkp_temp_high", day)
            if daily_temp_low is None:
                daily_temp_low = self.coordinator.get_forecast_daily_public("daily_bkp_temp_low", day)
            if daily_datetime is None:
                daily_datetime = self.coordinator.get_forecast_daily_public("daily_bkp_datetime", day)
            if day_condition in CONDITION_MAP:
                day_condition = CONDITION_MAP[day_condition]
            entry: dict = {
                ATTR_FORECAST_TEMP: daily_temp_high,
                ATTR_FORECAST_TEMP_LOW: daily_temp_low,
                ATTR_FORECAST_CONDITION: day_condition,
                ATTR_FORECAST_TIME: daily_datetime,
                ATTR_FORECAST_PRECIPITATION: safe_float(daily_precip_low),
            }
            if day_description:
                entry["description"] = day_description
            if daily_precip_low is not None:
                entry["precipitation_low_mm"] = safe_float(daily_precip_low)
            if daily_precip_high is not None:
                entry["precipitation_high_mm"] = safe_float(daily_precip_high)
            forecast.append(Forecast(entry))
        return forecast

